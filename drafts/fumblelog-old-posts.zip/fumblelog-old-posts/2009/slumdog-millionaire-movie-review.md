+++
title = "Slumdog Millionaire – Movie Review"
date = "2009-01-03T05:26:00-03:00"
type = "post"
tags = ['movies']
+++

<div class="posthaven-post-body">  <p>        <div class="posthaven-gallery" id="posthaven_gallery[445291]">
                  <p class="posthaven-file posthaven-file-image posthaven-file-state-processed">
          <img class="posthaven-gallery-image" src="https://phaven-prod.s3.amazonaws.com/files/image_part/asset/783136/m7m2TIenkHWhfAR0_OPS_jvYf94/media_httpwwwdivshare_Bkabd.jpg" />
        </p>

        </div>
</p>  <p>   This movie is certainly a <em>humanity</em> interest piece, something expected from every Oscar season. The story of a kid from the slums of Mumbai, and a game show years later with him at the verge of winning 20 million rupees, sets the right contrast for the entire movie. It has its fair share of dark humour and satire, like the shit clad child running for Amitabh’s autograph. An overdose of reality with a window into what life's like on the streets. </p>  <p>That was the better part of the review. For the lack of a better cliché, the film is a rollercoaster of emotions. I loved parts of it, I hated parts of it. The emotions in many parts of the movie seem overly forced and directed towards the American audiences and I'm sure they’ll love it. The 'real India' was exaggerated and glossed over and at all the wrong places. Moreover, the protagonist fails to evoke much emotion, once you've gotten over your initial curiosity. In the end, it starts resembling a  typical Bollywood melodramatic piece more, than a serious endeavor it sought out to be. The soundtrack by A.R. Rahman though, is not an add-on at all as in most Hindi movies, but is an essential gene in the pool.</p>  <p>At the same time I do feel that I am being overcritical. It’s still a must watch, more so because of the concept and contrast than the artistic merit of the director. There was a lot of potential in the movie but it might leave you with an aftertaste of dissatisfaction lingering inside. Perhaps I was expecting a little too much.</p>  <div class="blogger-post-footer"><img class="posterous_download_image" src="https://blogger.googleusercontent.com/tracker/895936018437336024-6293952152225007207?l=blog.sidmitra.com" height="1" alt="" width="1"></div></div>