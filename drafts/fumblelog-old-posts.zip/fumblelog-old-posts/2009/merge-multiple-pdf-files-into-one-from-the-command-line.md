+++
title = "Merge multiple PDF files into one from the command line"
date = "2009-09-10T08:18:00-04:00"
type = "post"
tags = ['apps']
+++

<div class="posthaven-post-body"><p><span>Unless you have Adobe Acrobat, it’s hard to find tools that allow you to play around with PDFs. For viewing i stick to Foxit for now, as it’s the fastest thing around. But when it comes to merging, there sure is a lack of good free tools. I looked

at </span><span> and some other ones, but they were purely crap. </span></p>
<p><span>The best tool i found was </span><strong><a href="http://www.accesspdf.com/pdftk/"><span>pdftk</span></a></strong><span>, the PDF Toolkit. It’s a simple exe that you copy to your system path and merging files is as easy as</span></p>
<p><span><em>pdftk 1.pdf 2.pdf 3.pdf cat output 123.pdf</em></span></p>
<p><span>It also allows you to merge/split files, update meta data etc. You can check out its </span><a href="http://www.accesspdf.com/pdftk/"><span>page</span></a><span> for more details. </span></p>
<div class="blogger-post-footer"><span><img class="posterous_download_image" src="https://blogger.googleusercontent.com/tracker/895936018437336024-1392907507213374259?l=blog.sidmitra.com" height="1" alt="" width="1"></span></div></div>