+++
title = "Primer – Movie Review"
date = "2009-02-05T07:30:00-03:00"
type = "post"
tags = ['movies']
+++

<div class="posthaven-post-body">        <div class="posthaven-gallery" id="posthaven_gallery[445289]">
                  <p class="posthaven-file posthaven-file-image posthaven-file-state-processed">
          <img class="posthaven-gallery-image" src="https://phaven-prod.s3.amazonaws.com/files/image_part/asset/783134/BjAEkl5Hp8uDPMnUPbV11dA6mYE/media_httpwwwdivshare_ctGaz.jpg" />
        </p>

        </div>
   <div align="justify">   <p>This film made in 2004 with just a budget of just $7000,  is relatively older than some I’ve reviewed recently. It came highly recommended by Jeff Cannata of <a href="http://revision3.com/trs/">TRS</a>, and sounded quite interesting. So I decided to catch it last week.</p>    <p>AND!! It turned out to be one hard movie to review. So this won’t try to be one. Firstly, this film is an orgy for people that love paradoxes. The movie in essence is about time travel, when a pair of engineers discover it by accident. It tells the story of how it effects people differently and how they behave. It talks about their temptations, their desire to become heroes. Towards the end the movie becomes convoluted in increasingly complex paradoxes, which to be honest left me completely clueless. But rather than throwing it out as a waste of my time, it had me so intrigued that I actually researched it, starting at its <a href="http://en.wikipedia.org/wiki/Primer_(film)">wikipedia</a> article. It was only then that I understood its premise properly. I can’t say that I still understand it fully, far from it! </p>    <p>It is pretty apparent that no attempt was made to dumb down any portions of it. So I’ll watch it a couple of more times and hope to fathom a majority of it. To any people who are fans of science fiction and thinking movies, this is a treat. It is perhaps meant to be a puzzle that you sit down with and ponder over, and it’s beauty lies in just that.</p>    <p><strong>Rating</strong>: 7/10</p> </div>  <div class="blogger-post-footer"><img class="posterous_download_image" src="https://blogger.googleusercontent.com/tracker/895936018437336024-3944385309004431730?l=blog.sidmitra.com" height="1" alt="" width="1"></div></div>