+++
title = "LinkStash – 22 Mar’ 2009"
date = "2009-03-22T04:09:00-04:00"
type = "post"
tags = ['linkstash']
+++

<div class="posthaven-post-body"><p><a href="http://www.istartedsomething.com/20090228/microsoft-office-labs-vision-2019-video/">Microsofts Vision for 2019</a> [vid]</p>
<p><a href="http://thevibe.socialvibe.com/wp-content/uploads/2009/02/musicthatmakesyoudum2bla.png">Music that makes you dumb</a> [pic] – Music choices versus SAT scores…. and some interesting finds. Now where did I put my Ninth Symphony Mp3.</p>
<p> </p>
<blockquote class="posterous_short_quote">
<p>Don't worry about people stealing your ideas. If your ideas are any good, you'll have to ram them down people's throats.</p>
<p>-Howard Aiken</p>
</blockquote>
<p> </p>
<p><a href="http://experiments.instrum3nt.com/markmahoney/ball/#" title="http://experiments.instrum3nt.com/markmahoney/ball/#">Chrome experiment</a> – Brilliant use of scripts.</p>
<p> <a href="http://sites.google.com/site/sxsw2009torrent/" title="http://sites.google.com/site/sxsw2009torrent/">SXSW 2009 Music</a>    -  6gb of SXSW music in 3 torrents!!!</p>
<p> </p>
<p>        <div class="posthaven-gallery" id="posthaven_gallery[445283]">
                  <p class="posthaven-file posthaven-file-image posthaven-file-state-processed">
          <img class="posthaven-gallery-image" src="https://phaven-prod.s3.amazonaws.com/files/image_part/asset/783131/4I3-VpA-SJD_l1g1lxjxoBjCHHI/media_httpfarm4static_IbGrl.jpg" />
        </p>

        </div>
</p>
<div>
<a href="http://www.flickr.com/photos/i_travel_east/3333203078/">n A w L ! n * f R ! D a Y * f A n D a N g o</a> by <a href="http://www.flickr.com/photos/i_travel_east/" title="http://www.flickr.com/photos/i_travel_east/">I Travel East</a>
</div>
<p> </p>
<p><a href="http://coda.fm">Coda.fm</a> – For you music and bittorent fixation.</p>
<p><a href="http://www.grcade.com/viewtopic.php?f=7&amp;t=2217" title="http://www.grcade.com/viewtopic.php?f=7&amp;t=2217">BLH's tour of Chernobyl</a> – What Chernobyl looks like after 23 years.</p>
<div class="blogger-post-footer"><img class="posterous_download_image" src="https://blogger.googleusercontent.com/tracker/895936018437336024-8905520804044959926?l=blog.sidmitra.com" height="1" alt="" width="1"></div></div>