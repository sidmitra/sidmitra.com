+++
title = "LinkStash – 24 Feb’ 2009"
date = "2009-02-24T01:26:00-03:00"
type = "post"
tags = ['linkstash']
+++

<div class="posthaven-post-body"><p><a href="http://www.themorningnews.org/archives/reviews/mindfuck_movies.php">Mindfuck movies</a> – Here are some good recommendations from The Morning news for the coming weekend.</p>
<p><br><a href="http://www.cinemablend.com/new/Rant-Really-Slumdog-Millionaire-12109.html" title="http://www.cinemablend.com/new/Rant-Really-Slumdog-Millionaire-12109.html">Really? Slumdog-Millionaire?</a> – My <a href="http://fumblelog.blogspot.com/2009/01/slumdog-millionaire-movie-review.html">thoughts</a> exactly.</p>
<p> </p>
<blockquote class="posterous_short_quote">
<p>Charles M. Schulz - "All you need is love. But a little chocolate now and then doesn't hurt."</p>
</blockquote>
<p> </p>
<p align="left"><a href="http://www.flickr.com/photos/bjurman/3281205563/sizes/o/">        <div class="posthaven-gallery" id="posthaven_gallery[445286]">
                  <p class="posthaven-file posthaven-file-image posthaven-file-state-processed">
          <img class="posthaven-gallery-image" src="https://phaven-prod.s3.amazonaws.com/files/image_part/asset/783133/0dR2HvnVHaEoBtxOSDUfph7wVSc/media_httpfarm4static_zidFk.jpg" />
        </p>

        </div>
 </a> <br><a href="http://www.flickr.com/photos/bjurman/3281205563/">In the subway</a> by <a href="http://www.flickr.com/photos/bjurman/" title="http://www.flickr.com/photos/bjurman/">Kaj Bjurman</a></p>
<p align="left"> </p>
<p>The most awesome <a href="http://www.youtube.com/watch?v=EKL6elkbFy0">pencil sharpener</a> -</p>
<p align="center">
<object height="285" width="340">
<param name="movie" value="http://www.youtube.com/v/EKL6elkbFy0&amp;hl=en&amp;fs=1&amp;rel=0&amp;color1=0x3a3a3a&amp;color2=0x999999&amp;border=1">
<param name="allowFullScreen" value="true">
<param name="allowscriptaccess" value="always">
<embed src="http://www.youtube.com/v/EKL6elkbFy0&amp;hl=en&amp;fs=1&amp;rel=0&amp;color1=0x3a3a3a&amp;color2=0x999999&amp;border=1" type="application/x-shockwave-flash" height="285" width="340"></embed></object>

</p>
<p> </p>
<p> </p>
<blockquote>
<p>You have misunderstood your place in the food chain. You are google's product. Your PC is a crucial part of the delivery mechanism by which you are made available to google's customers.</p>
<p>- by <a href="http://www.reddit.com/r/programming/comments/7790q/after_installing_google_chrome_why_have_i/c05v6sb">keithb</a></p>
</blockquote>
<p> </p>
<p><a href="http://streamdrag.com/">StreamDrag</a> – Stream  all your favourite songs from YouTube videos.</p>
<p> </p>
<p><a href="http://video.google.com/videoplay?docid=-2160824376898701015">No-Tech hacking</a> - An impressive talk by Johnny Long, on how to snipe and gather information.</p>
<p align="center"><embed src="http://video.google.com/googleplayer.swf?docid=-2160824376898701015&amp;hl=en&amp;fs=true" type="application/x-shockwave-flash"></embed></p>
<p> </p>
<p>The new <a href="http://www.getmiro.com/">Miro</a> is awesome. It was a huge  memory hog in the past but not anymore. It now features a pretty decent UI, with new features like adding sites that you can browse directly inside. It records a consistent under 50 MB memory usage on mine, which is less than half that of the previous version. It now has separate audio and video feed sections. The in built browser feels more responsive and so does the media player (now you can pop it out into a separate window too).</p>
<div class="blogger-post-footer"><img class="posterous_download_image" src="https://blogger.googleusercontent.com/tracker/895936018437336024-6103564224860284332?l=blog.sidmitra.com" height="1" alt="" width="1"></div></div>