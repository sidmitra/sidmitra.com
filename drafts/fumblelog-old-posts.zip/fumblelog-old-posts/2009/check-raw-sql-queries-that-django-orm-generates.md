+++
title = "Check raw SQL queries that Django ORM generates"
date = "2009-12-26T09:25:00-03:00"
type = "post"
tags = ['django', 'programming']
+++

<div class="posthaven-post-body"><p><span>To find out what queries Django generates behind all that ORM magic, make sure that settings.DEBUG=True, and then run:</span></p>
<p></p><pre><code>&gt;&gt;&gt; from django.db import connection
&gt;&gt;&gt; connection.queries
[{'sql': u'SELECT `auth_user`.`id`, `auth_user`.`username`, 
`auth_user`.`first_name`, `auth_user`.`last_name`, `auth_user`.`email`, 
`auth_user`.`password`, `auth_user`.`is_staff`, `auth_user`.`is_active`, 
`auth_user`.`is_superuser`, `auth_user`.`last_login`, 
`auth_user`.`date_joined` FROM `auth_user` 
WHERE `auth_user`.`id` = 2 ',  'time': '0.002'}, ]</code></pre>
<p><span>The </span><em><span>connection.queries</span></em><span> attribute spits out a list of dictionaries of all queries in order of execution. The dictionary contains the actual SQL executed along with the time it took for the same.</span></p>
<p><span>To see the last query run, you can use </span><em><span>pop</span></em><span>:</span></p>
<p></p><pre><code>&gt;&gt;&gt; connection.queries.pop</code></pre>
<p><span>and to explore further methods, attributes on the </span><em><span>connection</span></em><span> object, you can always do:</span></p>
<p></p><pre><code>&gt;&gt;&gt; dir(connection.queries)</code></pre>
<div class="blogger-post-footer"><span><img class="posterous_download_image" src="https://blogger.googleusercontent.com/tracker/895936018437336024-6342264512898934235?l=blog.sidmitra.com" height="1" alt="" width="1"></span></div></div>