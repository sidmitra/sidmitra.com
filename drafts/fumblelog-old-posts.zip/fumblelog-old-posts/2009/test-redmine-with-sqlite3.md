+++
title = "Test Redmine with sqlite3"
date = "2009-08-18T03:45:00-04:00"
type = "post"
tags = ['apps']
+++

<div class="posthaven-post-body"><p>I asked around on <a href="http://news.ycombinator.com/item?id=605291">HN</a> a while back for a project management solution. I’ll do a comparison post soon among all the ones i checked out. I also tested <a href="http://www.redmine.org/">Redmine</a>, which came highly recommended.  Using it with SQLite on Windows might result in an nmake error, while installing the ruby-sqlite3 gem. Make the minor changes mentioned below to make it work.</p>
<p>You can choose to download it from <a href="http://rubyforge.org/frs/?group_id=1850">RubyForge</a>, or plain old svn with</p>
<p><em>svn co <a href="http://redmine.rubyforge.org/svn/trunk">http://redmine.rubyforge.org/svn/trunk</a> redmine</em></p>
<p>You might also want to check out the Bitnami readymade stack at <a href="http://bitnami.org/stack/redmine" title="http://bitnami.org/stack/redmine">http://bitnami.org/stack/redmine</a>.</p>
<p> </p>
<p>Redmine is based on Ruby on Rails, so you need to install those two first. The install guide on their site uses MySQL by default, but we want to use the more portable SQLite instead. To do that, you only need to modify/add to the steps listed in <a href="http://www.redmine.org/wiki/redmine/RedmineInstall" title="http://www.redmine.org/wiki/redmine/RedmineInstall">http://www.redmine.org/wiki/redmine/RedmineInstall</a>, as follows:</p>
<p> </p>
<ul>
<li>Install the Ruby sqlite3 gem, after installing Ruby and Rails. Only the specific version mentioned below works on my machine. If you don’t specify the version, it may result in an nmake error on Windows.
<p> <em>gem install sqlite3-ruby -v=1.2.1 </em></p>
</li>
</ul><ul>
<li>Follow the steps in the install guide till where it asks you to copy the database.yml . Then in database.yml, you could replace
<p><em>production:          <br>adapter: mysql           <br>database: redmine           <br>host: localhost           <br>username: root           <br>password:           <br>encoding: utf8</em></p>
by <p></p>
<em>production:        <br>adapter: sqlite3         <br>dbfile: db/redmine.db</em> </li>
<br><li>The rest of the steps stay the same, for eg. the following commands
<p><em>rake db:migrate RAILS_ENV="production"</em></p>
<em> </em>
<p><em>rake redmine:load_default_data RAILS_ENV="production"</em></p>
<em> </em>
<p><em>ruby script/server webrick -e production</em></p>
</li>
</ul><p>The rest of the steps should be similar to the one mentioned on the install documentation, for example setting permissions to directories etc., if you’re on Linux.</p>
<div class="blogger-post-footer"><img class="posterous_download_image" src="https://blogger.googleusercontent.com/tracker/895936018437336024-5709465968091499792?l=blog.sidmitra.com" height="1" alt="" width="1"></div></div>