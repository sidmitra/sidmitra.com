+++
title = "Django complains “Unable to Open Database File”, with SQLite3"
date = "2009-10-09T22:29:00-04:00"
type = "post"
tags = ['django', 'programming']
+++

<div class="posthaven-post-body"><p>This is a fairly common gotcha, that i had forgotten about until i wasted half a day troubleshooting it again. </p>  <p> To solve, make sure the database file itself is writable, and not only that, also make sure that the parent directory is writable as well so the database engine can make temporary files. So just chmod 777 to check if it works :-) but remember to choose your permissions carefully later.</p>  <p>Ref: <a href="http://code.djangoproject.com/wiki/NewbieMistakes#DjangosaysUnabletoOpenDatabaseFilewhenusingSQLite3">http://code.djangoproject.com/wiki/NewbieMistakes#DjangosaysUnabletoOpenDatabaseFilewhenusingSQLite3</a></p>  <div class="blogger-post-footer"><img class="posterous_download_image" src="https://blogger.googleusercontent.com/tracker/895936018437336024-8579801732875814964?l=blog.sidmitra.com" height="1" alt="" width="1"></div></div>