+++
title = "Access the App Engine datastore on your localhost"
date = "2009-08-17T21:26:00-04:00"
type = "post"
tags = ['programming']
+++

<div class="posthaven-post-body"><p>The data store on the local AppEngine dev server is available at:</p>  <p><a href="http://localhost:8080/_ah/admin/datastore" title="http://localhost:8080/_ah/admin/datastore">http://localhost:8080/_ah/admin/datastore</a></p>  <div class="blogger-post-footer"><img class="posterous_download_image" src="https://blogger.googleusercontent.com/tracker/895936018437336024-3838576020352474789?l=blog.sidmitra.com" height="1" alt="" width="1"></div></div>