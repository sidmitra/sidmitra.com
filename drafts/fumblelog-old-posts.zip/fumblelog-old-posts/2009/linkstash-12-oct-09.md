+++
title = "LinkStash - 12 Oct '09"
date = "2009-10-11T11:10:00-03:00"
type = "post"
tags = ['linkstash', 'music']
+++

<div class="posthaven-post-body"><p>I cleared out my Google Reader unread count after months. I’m not sure about the actual numbers but my guess is there were more than 10,000 items there.</p>  <p>I was listening to cover songs on <a href="http://copycats.tumblr.com" title="http://copycats.tumblr.com">http://copycats.tumblr.com</a> and these are some of the ones i loved recently.</p>  <ul>
<li>
<a href="http://copycats.tumblr.com/post/207367338" title="http://copycats.tumblr.com/post/207367338">Build Me Up by Rhymefest f/ Ol’ Dirty Bastard</a>, originally by The Foundations </li>    <li>
<a href="http://copycats.tumblr.com/post/209779300" title="http://copycats.tumblr.com/post/209779300">Feel Good Inc. by Cookin’ On 3 Burners</a>, originally by Gorillaz </li>    <li>
<a href="http://copycats.tumblr.com/post/196584837" title="http://copycats.tumblr.com/post/196584837">Seven Nation Army by Kate Nash</a>, originally by The White Stripes </li>    <li>
<a href="http://copycats.tumblr.com/post/185672859" title="http://copycats.tumblr.com/post/185672859">Leaving on a Jet Plane by Sophie Barker</a>, originally by John Denver </li>    <li>
<a href="http://copycats.tumblr.com/post/185598778" title="http://copycats.tumblr.com/post/185598778">What Goes Around … / …Comes Around by Timberfakes</a>, originally by Justin Timberlake </li> </ul><p> </p>  <div align="center">
<a href="http://www.flickr.com/photos/pilou/3940812872/">Nature Lover</a> by Philippe Sainte-Laudy <a href="http://www.flickr.com/photos/pilou/3940812872/" title="http://www.flickr.com/photos/pilou/3940812872/">        <div class="posthaven-gallery" id="posthaven_gallery[445312]">
                  <p class="posthaven-file posthaven-file-image posthaven-file-state-processed">
          <img class="posthaven-gallery-image" src="https://phaven-prod.s3.amazonaws.com/files/image_part/asset/783151/gpyXwdC9S9EymnJmz6N32IIVqks/media_httpfarm3static_BgEoo.jpg" />
        </p>

        </div>
 </a>
</div>  <div class="blogger-post-footer"><img class="posterous_download_image" src="https://blogger.googleusercontent.com/tracker/895936018437336024-7696651475587693783?l=blog.sidmitra.com" height="1" alt="" width="1"></div></div>