+++
title = "Seven Pounds – Movie Review"
date = "2009-01-16T08:49:00-03:00"
type = "post"
tags = ['movies']
+++

<div class="posthaven-post-body">         <div class="posthaven-gallery" id="posthaven_gallery[445290]">
                  <p class="posthaven-file posthaven-file-image posthaven-file-state-processed">
          <img class="posthaven-gallery-image" src="https://phaven-prod.s3.amazonaws.com/files/image_part/asset/783135/Y3e-nMbcHp7GdZMpSILCa3cP61w/media_httpwwwdivshare_fdbra.jpg" />
        </p>

        </div>
   <div align="justify">   <p>An emotional drama starring Will Smith as an IRS agent (read tax collector) trying to redeem a mistake that killed seven people, by helping seven strangers. Smith also managing to recover from the disaster that <em>Hancock</em> was, and gives a stellar emotional performance in the same genre as <em>The Pursuit of Happyness. </em>If you liked that movie then I am positive you’ll like this one, and leave you teary eyed at end. On the other hand that is also my only gripe. The initial one line description sums up the movie entirely. Its only attempt is to make your eyes moisten, although it does succeed with a highly depressing end. Rosario Dawson turned out to be the surprise act for me in this one, with a prefect portrayal of a dying girl. The movie is slightly confusing for the major part and you’re left wondering about the motives behind the protagonists actions, but it clears out quite magnificently in the end. </p>    <p>Very few characters, small storyline and I’m still amazed at how much the movie accomplished in the end. So I would probably rate it around <strong>7/10 </strong>and is probably on of the best movies out of 2008 and I liked it better than Slumdog. If you’re into serious, emotional movies then this one’s for you.</p> </div>  <p><strong>Rating: 7/10</strong></p>  <div class="blogger-post-footer"><img class="posterous_download_image" src="https://blogger.googleusercontent.com/tracker/895936018437336024-457165342117437006?l=blog.sidmitra.com" height="1" alt="" width="1"></div></div>