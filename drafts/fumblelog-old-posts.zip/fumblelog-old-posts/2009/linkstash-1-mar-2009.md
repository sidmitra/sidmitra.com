+++
title = "LinkStash – 1 Mar’ 2009"
date = "2009-02-28T20:35:00-03:00"
type = "post"
tags = ['linkstash']
+++

<div class="posthaven-post-body">
<p> <a href="http://www.sixwordstories.net/category/subject/sci-fi/page/2/" title="http://www.sixwordstories.net/category/subject/sci-fi/page/2/">Six word sci-fi stories</a> -</p>
<blockquote class="posterous_short_quote">
<p>Last man on earth. Hears knock.</p>
<p>—Pete Berg</p>
</blockquote>
<p>  <a href="http://www.flickr.com/photos/evanbooth/291214973/in/set-72157594364518048/" title="http://www.flickr.com/photos/evanbooth/291214973/in/set-72157594364518048/"></a></p>
<p>        <div class="posthaven-gallery" id="posthaven_gallery[445284]">
                  <p class="posthaven-file posthaven-file-image posthaven-file-state-processed">
          <img class="posthaven-gallery-image" src="https://phaven-prod.s3.amazonaws.com/files/image_part/asset/783132/rgCWFmiZB449qYhlf-Tu7u6nQiE/media_httpfarm1static_xIbJk.jpg" />
        </p>

        </div>
</p>
<p><a href="http://www.flickr.com/photos/evanbooth/291214973/in/set-72157594364518048/" title="http://www.flickr.com/photos/evanbooth/291214973/in/set-72157594364518048/">Gaping hole halloween costume</a> -  by  <a href="http://www.flickr.com/photos/evanbooth/" title="http://www.flickr.com/photos/evanbooth/">evanbooth</a></p>
<p> </p>
<p><a href="http://imgur.com/BLA6" title="http://imgur.com/BLA6">Pinocchio paradox</a> – pic….lol.</p>
<p><a href="http://www.ted.com/talks/view/id/473">Evan Williams talks about unexpected uses driving Twitter growth.</a></p>
<div>
<p>
<object height="326" width="446">
<param name="movie" value="http://video.ted.com/assets/player/swf/EmbedPlayer.swf">
<param name="allowFullScreen" value="true">
<param name="wmode" value="transparent">
<param name="bgColor" value="#ffffff">
<param name="flashvars" value="vu=http://video.ted.com/talks/embed/EvanWilliams_2009-embed_high.flv&amp;su=http://images.ted.com/images/ted/tedindex/embed-posters/EvanWilliams-2009.embed_thumbnail.jpg&amp;vw=432&amp;vh=240&amp;ap=0&amp;ti=473">
<embed src="http://video.ted.com/assets/player/swf/EmbedPlayer.swf" wmode="transparent" type="application/x-shockwave-flash" height="326" flashvars="vu=http://video.ted.com/talks/embed/EvanWilliams_2009-embed_high.flv&amp;su=http://images.ted.com/images/ted/tedindex/embed-posters/EvanWilliams-2009.embed_thumbnail.jpg&amp;vw=432&amp;vh=240&amp;ap=0&amp;ti=473" width="446"></embed></object>

</p>
</div>
<p> </p>
<p><a href="http://www.fourmilab.ch/hackdiet/www/hackdiet.html" title="http://www.fourmilab.ch/hackdiet/www/hackdiet.html">The Hacker's Diet</a> – by John Walker.</p>
<div class="blogger-post-footer"><img class="posterous_download_image" src="https://blogger.googleusercontent.com/tracker/895936018437336024-2214060371671032973?l=blog.sidmitra.com" height="1" alt="" width="1"></div></div>