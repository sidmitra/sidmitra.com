+++
title = "Stumble your way to new music"
date = "2008-07-22T03:06:00-04:00"
type = "post"
tags = ['music']
+++

<div class="posthaven-post-body">  <p align="center"> </p>  <p align="center">        <div class="posthaven-gallery" id="posthaven_gallery[445295]">
                  <p class="posthaven-file posthaven-file-image posthaven-file-state-processed">
          <img class="posthaven-gallery-image" src="https://phaven-prod.s3.amazonaws.com/files/image_part/asset/783139/M1IpvbbPn2IT98wYNOKcSoxngaw/media_httpwwwdivshare_AtigC.jpg" />
        </p>

        </div>
</p>  <p> </p>  <p><a href="http://www.stumbleaudio.com/">StumbleAudio</a> is another new social music discovery site. It lets you stumble upon new music in a neat cover flow’ish interface. Just select a genre and it automatically prepares a playlist of interesting new songs and artists. In case you like what you’re listening to, then give it a thumbs up. If you don’t then press the stumble button to find something else more to your liking. Pretty simple!! right? :-D</p>  <p>It currently has around 2 million tracks to discover and the artists get paid when you listen to their music too.  It reminds me of Pandora, which is now closed to residents outside the US. The site features mostly indie artists, so its very easy find music that you haven’t heard before.</p>  <div class="blogger-post-footer"><img class="posterous_download_image" src="https://blogger.googleusercontent.com/tracker/895936018437336024-291166007664289825?l=blog.sidmitra.com" height="1" alt="" width="1"></div></div>