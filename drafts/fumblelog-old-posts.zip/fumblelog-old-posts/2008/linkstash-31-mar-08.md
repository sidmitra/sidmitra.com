+++
title = "LinkStash - 31 Mar' 08"
date = "2008-03-31T03:08:00-04:00"
type = "post"
tags = ['linkstash']
+++

<div class="posthaven-post-body">  <ul>
<li>
<a href="http://www.zoo-m.com/flickr-storm/" title="http://www.zoo-m.com/flickr-storm/">FlickrStorm</a> - A neat, simple and more effective way to search flickr. </li> </ul><p> </p>  <div align="center">        <div class="posthaven-gallery" id="posthaven_gallery[445300]">
                  <p class="posthaven-file posthaven-file-image posthaven-file-state-processed">
          <img class="posthaven-gallery-image" src="https://phaven-prod.s3.amazonaws.com/files/image_part/asset/783142/RJ89Jjk5AIjsnUAAoj7isjnFWf0/media_httpfarm4static_HDpsi.jpg" />
        </p>

        </div>
     <p>42 / 52: Fear by <a href="http://www.flickr.com/photos/lbpuppy/">teddy</a></p> </div>  <p> </p>  <ul>
<li>
<a href="http://www.imdb.com/title/tt0475343/" title="http://www.imdb.com/title/tt0475343/">Coolest zombie movie title ever</a> - where can I get this?? </li> </ul><p> </p>  <ul>
<li>
<a href="http://www.labnol.org/internet/tools/best-online-tools-for-webmasters-know-everything-about-websites/2744/" title="http://www.labnol.org/internet/tools/best-online-tools-for-webmasters-know-everything-about-websites/2744/">Best online tools for</a> - To help you get tons of info on a website. </li> </ul><p> </p>  <ul>
<li>
<a href="http://youtube.com/watch?v=JdxkVQy7QLM&amp;re">Rob Paravonian</a> - a comedian/musician shares how much he likes Pachelbel's Canon in D on a cello. Really funny!! </li> </ul><p> </p>  <div align="center">   <div class="wlWriterSmartContent" align="center"><div><object height="355" width="425"><param name="movie" value="http://www.youtube.com/v/JdxkVQy7QLM&amp;rel=0&amp;color1=0x3a3a3a&amp;color2=0x999999&amp;border=1&amp;hl=en">
<param name="wmode" value="transparent">
<embed src="http://www.youtube.com/v/JdxkVQy7QLM&amp;rel=0&amp;color1=0x3a3a3a&amp;color2=0x999999&amp;border=1&amp;hl=en" type="application/x-shockwave-flash" wmode="transparent" height="355" width="425"></embed></object>

</div></div> </div>  <p> </p>  <ul>
<li>
<a href="http://www.telegraph.co.uk/connected/main.jhtml?xml=/connected/2008/03/30/sv_101websites.xml" title="http://www.telegraph.co.uk/connected/main.jhtml?xml=/connected/2008/03/30/sv_101websites.xml">The 101 most useful websites</a> - courtesy, Telegraph UK. </li> </ul><p> </p>  <ul>
<li>
<a href="http://movies.popcrunch.com/50-movies-that-all-guys-should-see-before-they-die-a-modern-guide/" title="http://movies.popcrunch.com/50-movies-that-all-guys-should-see-before-they-die-a-modern-guide/">50 movies that all guys should see before they die</a> - Not really impressed with Rank 1, but +1 for number 2 :-D </li> </ul><p> </p>  <ul>
<li>
<a href="http://www.timemachiner.com/" title="http://www.timemachiner.com/">Time Machiner</a> - Say hi to the future you, or maybe rant your heart out. Worth a try ;-) </li> </ul><p> </p>  <blockquote>   <p><em>Catch further issues by subscribing to my </em><a href="http://feeds.feedburner.com/fumblelog"><strong><em>RSS Feed</em></strong></a><em>.</em></p>
</blockquote>  <div class="blogger-post-footer"><img class="posterous_download_image" src="https://blogger.googleusercontent.com/tracker/895936018437336024-3205578941736518808?l=blog.sidmitra.com" height="1" alt="" width="1"></div></div>