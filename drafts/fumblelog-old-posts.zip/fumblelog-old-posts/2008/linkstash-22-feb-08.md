+++
title = "LinkStash - 22 Feb '08"
date = "2008-02-22T04:28:00-03:00"
type = "post"
tags = ['linkstash']
+++

<div class="posthaven-post-body">  <p><strong>Pics</strong></p>  <ul>
<li>
<a href="//funtasticus.com/20080207/creative-ads-2/#more-1901" title="http://funtasticus.com/20080207/creative-ads-2/#more-1901"><strong>Creative Ads</strong></a> - Good looking ads ... but I'm not sure I would remember what products they're for. </li> </ul><p> </p>  <ul>
<li>Here are some interesting pics from my Flickr Feed </li> </ul><p> </p>  <div align="center">   <p>        <div class="posthaven-gallery" id="posthaven_gallery[445309]">
                  <p class="posthaven-file posthaven-file-image posthaven-file-state-processed">
          <img class="posthaven-gallery-image" src="https://phaven-prod.s3.amazonaws.com/files/image_part/asset/783148/M2OXXSJUJYyS3BKsr-P2TYonZLE/media_httpfarm3static_GgpHr.jpg" />
        </p>

        </div>
</p>    <p>Tokyo from Mori Towers - <a href="http://www.flickr.com/photos/neardc/" title="http://www.flickr.com/photos/neardc/">neardc</a></p>    <p>        <div class="posthaven-gallery" id="posthaven_gallery[445310]">
                  <p class="posthaven-file posthaven-file-image posthaven-file-state-processed">
          <img class="posthaven-gallery-image" src="https://phaven-prod.s3.amazonaws.com/files/image_part/asset/783149/E8Ap-umEIs4FV6Oi__-M0IUPR7o/media_httpfarm3static_wrqjD.jpg" />
        </p>

        </div>
</p>    <p>Toronto Harbour in Winter - <a href="http://www.flickr.com/photos/mr_fabulous/" title="http://www.flickr.com/photos/mr_fabulous/">peter bowers</a></p> </div>  <p> </p>  <p><strong>Vids</strong></p>  <ul>
<li>
<a href="http://www.uniquepeek.com/viewpage.php?page_id=1517" title="http://www.uniquepeek.com/viewpage.php?page_id=1517"><strong>1500 XBox Hard Drives</strong></a> - What DO you do??  :-( I'm sad for the last 2. </li> </ul><p> </p>  <p><strong>LifeHacks</strong></p>  <ul>
<li>
<a href="http://calnewport.com/blog/?p=266" title="http://calnewport.com/blog/?p=266"><strong>The Art of Speaking</strong></a> - solid tips from Professor Patrick Henry Winston on how to speak. </li> </ul><p> </p>  <ul>
<li>
<a href="http://zenhabits.net/2008/02/17-fitness-truths-to-get-you-in-great-shape/" title="http://zenhabits.net/2008/02/17-fitness-truths-to-get-you-in-great-shape/"><strong>17 Fitness Truths To Get You In Great Shape</strong></a> - Easier said than done though. </li> </ul><p><strong></strong></p>  <p><strong>DevCorner</strong></p>  <ul>
<li>This week, Jeff Atwood explains the <a href="http://www.codinghorror.com/blog/archives/001054.html"><strong>Years of Experience Myth</strong></a>, -  " they've forgotten that what software developers do best is learn. " </li> </ul><p> </p>  <ul>
<li>
<a href="http://friendfeed.com/" title="http://friendfeed.com/"><strong>FreindFeed</strong></a> is now under private beta testing (so send in a request). It's a tool that lets you see what your friends family are upto on the web. </li> </ul><p> </p>  <ul>
<li>
<a href="http://www.webupon.com/Web-Talk/50-Great-Gadgets-That-No-Geek-or-Nerd-Should-Live-Without.81133" title="http://www.webupon.com/Web-Talk/50-Great-Gadgets-That-No-Geek-or-Nerd-Should-Live-Without.81133"><strong>50 Great gadgets for the Geeks</strong></a> - I want one of these :-( </li> </ul><p> </p>  <div align="center">        <div class="posthaven-gallery" id="posthaven_gallery[445311]">
                  <p class="posthaven-file posthaven-file-image posthaven-file-state-processed">
          <img class="posthaven-gallery-image" src="https://phaven-prod.s3.amazonaws.com/files/image_part/asset/783150/M9QYlkpppawILxfQALPVSoF1D2I/media_https3amazonaws_Gzauj.jpg" />
        </p>

        </div>
 </div>  <div align="center"> </div>  <p align="center"></p>  <p> </p>  <ul>
<li>
<a href="http://unxutils.sourceforge.net/"><strong>GnuUtils</strong></a> - The native win32 ports. No Cygwin required :-D </li> </ul><p> </p>  <p> </p>  <blockquote>   <p>Catch further issues by subscribing to my <a href="http://feeds.feedburner.com/fumblelog"><strong>RSS Feed</strong></a>.</p>
</blockquote>  <div class="blogger-post-footer"><img class="posterous_download_image" src="https://blogger.googleusercontent.com/tracker/895936018437336024-729781235243790937?l=blog.sidmitra.com" height="1" alt="" width="1"></div></div>