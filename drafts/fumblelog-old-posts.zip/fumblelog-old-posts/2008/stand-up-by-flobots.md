+++
title = "Stand Up by Flobots"
date = "2008-06-18T03:19:00-04:00"
type = "post"
tags = ['music']
+++

<div class="posthaven-post-body">         <div class="posthaven-gallery" id="posthaven_gallery[445298]">
                  <p class="posthaven-file posthaven-file-image posthaven-file-state-processed">
          <img class="posthaven-gallery-image" src="https://phaven-prod.s3.amazonaws.com/files/image_part/asset/783141/SHQkTfflFpDH7Z7Q-V9EsoseTco/media_httpwwwdivshare_axDiD.jpg" />
        </p>

        </div>
  <p><object height="28" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="300"><param name="movie" value="http://www.divshare.com/flash/playlist?myId=4769164-420">
<embed name="divplaylist" src="http://www.divshare.com/flash/playlist?myId=4769164-420" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" height="28" width="300"></embed></object></p>  <p>Flobots, “<em><strong>Stand Up”</strong></em> comes from their second album <strong><em>Fight with Tools.</em></strong> </p>  <p></p>  <p></p>  <p></p>  <p></p>  <p></p>  <p></p>  <p></p>  <p></p>  <p></p>  <p></p>  <p></p>  <p>The song starts uniquely with a lead violin, and blends into a soft dope beat with lyrics showing more of a political, social flavour. Overall a highly recommended song/band. Also don’t forget to listen to <em><strong>Handlebars</strong></em> from the same album. It’s one of my favourite songs.</p>  <p><strong><a href="http://www.thesixtyone.com/#/Flobots/" title="on sixtyone.com">Listen to more of Flobots..</a></strong></p>  <div class="blogger-post-footer"><img class="posterous_download_image" src="https://blogger.googleusercontent.com/tracker/895936018437336024-3192622910287625982?l=blog.sidmitra.com" height="1" alt="" width="1"></div></div>