+++
title = "Fashion Nugget by Cake"
date = "2008-11-11T08:36:00-03:00"
type = "post"
tags = ['music']
+++

<div class="posthaven-post-body">  <p>Did you know the <a href="http://thepiratebay.org/">PirateBay</a> also gives you music recommendations?? Every download page related to music has a detailed artist info section with a list of artists very similar to one you’re trying to download and it’s pretty darn useful. A preliminary search for some mellow bands led me to a dozen year old album called <strong>Fashion Nugget</strong>, by an alternative rock band called the <strong>Cake</strong>.</p>  <p> </p>         <div class="posthaven-gallery" id="posthaven_gallery[445292]">
                  <p class="posthaven-file posthaven-file-image posthaven-file-state-processed">
          <img class="posthaven-gallery-image" src="https://phaven-prod.s3.amazonaws.com/files/image_part/asset/783137/Sj2zzf7TeWf9yTutDQ_3VzPtQzs/media_httpwwwdivshare_gzydp.jpg" />
        </p>

        </div>
   <p>The album contains some gems like ‘<strong>Nugget</strong>’, a cool song with a funk feel, although I should probably warn you that it periodically contains a well known four letter :-D. They also managed to make use of that word in a remake of the Gloria Gaynor’s ‘<strong>I Will Survive</strong>’. A little research leads to a nifty piece of trivia that this it is also the goal music of the Turkish football club <em>Galatasaray SK</em>. The album starts with a trumpetty-sad but still rythmic number titled ‘<strong>Frank Sinatra</strong>’, which has had the honour of appearing in the hit series <em>The Sopranos. </em>It seems like a pretty well know band and I'm surprised at not having heard of them. Moreover, this album has left me intrigued and curious about their music and I hope to find more and more of it. I give this album my thumbs up!! </p>  <p>You can get a taste of their music <a href="http://www.cakemusic.com/music.html">here</a>.</p>  <div class="blogger-post-footer"><img class="posterous_download_image" src="https://blogger.googleusercontent.com/tracker/895936018437336024-8008228703936524781?l=blog.sidmitra.com" height="1" alt="" width="1"></div></div>