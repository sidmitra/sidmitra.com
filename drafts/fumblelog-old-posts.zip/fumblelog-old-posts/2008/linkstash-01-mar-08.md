+++
title = "LinkStash - 01 Mar '08"
date = "2008-03-01T04:40:00-03:00"
type = "post"
tags = ['linkstash']
+++

<div class="posthaven-post-body">  <ul>
<li>
<a href="http://www.byte.com/abrash/" title="http://www.byte.com/abrash/"><strong>Graphics Programming Black Book</strong></a> - Michael Abrash, On assembly Language, profiling, code testing and optimization (70 Chapters as PDF) ' </li> </ul><p> </p>  <div align="center">   <p>        <div class="posthaven-gallery" id="posthaven_gallery[445305]">
                  <p class="posthaven-file posthaven-file-image posthaven-file-state-processed">
          <img class="posthaven-gallery-image" src="https://phaven-prod.s3.amazonaws.com/files/image_part/asset/783146/9QnKlEYSSLOrXvdwq6IXAsHP83E/media_httpfarm3static_ynxry.jpg" />
        </p>

        </div>
</p>    <p>Shores on the road to Hope - by <a href="http://flickr.com/photos/warzauwynn/" title="http://flickr.com/photos/warzauwynn/">warzauwynn</a></p> </div>  <p> </p>  <ul>
<li>
<a href="http://www.youtube.com/watch?v=Zto6aTZM9t0"><strong>Nokia Morph</strong></a> </li> </ul><p> </p>  <div align="center">   <p><embed src="http://www.youtube.com/v/Zto6aTZM9t0" type="application/x-shockwave-flash" wmode="transparent" height="229" style="height: 229px;" width="320"></embed></p>    <p> </p> </div>  <ul>
<li>
<a href="http://isites.harvard.edu/fs/html/icb.topic58703/winston1.html" title="http://isites.harvard.edu/fs/html/icb.topic58703/winston1.html"><strong>How to speak</strong></a> - Patrick Winston, contains embedded videos. </li> </ul><p> </p>  <ul>
<li>
<a href="http://freshome.com/2008/02/25/30-of-the-most-creative-bookshelves-designs/" title="http://freshome.com/2008/02/25/30-of-the-most-creative-bookshelves-designs/"><strong>30 of the Most Creative Bookshelves Designs</strong></a> - Too bad I don't have a bachelor pad yet,  to put one of these in yet :-( </li> </ul><p> </p>  <ul>
<li>
<a href="http://forums.facepunchstudios.com/showthread.php?t=199817" title="http://forums.facepunchstudios.com/showthread.php?t=199817"><strong>Free Games that don't suck</strong></a> - A really neat list... and be sure to try 'N'. </li> </ul><p> </p>  <ul>
<li>
<a href="http://danidraws.com/2007/12/06/50-facial-expressions-and-how-to-draw-them" title="http://danidraws.com/2007/12/06/50-facial-expressions-and-how-to-draw-them"><strong>50 Facial Expressions and How to Draw Them</strong></a> - Just something to practice during those long lectures. </li> </ul><p> </p>  <ul>
<li> <a href="http://www.kontraband.com/show/show.asp?ID=9981" title="http://www.kontraband.com/show/show.asp?ID=9981"><strong>Sweet Child of Mine</strong></a> - The Indian version :-D </li> </ul><p> </p>  <blockquote>   <p>Catch further issues by subscribing to my <a href="http://feeds.feedburner.com/fumbl"><strong>RSS Feed</strong>.</a></p>
</blockquote>  <div class="blogger-post-footer"><img class="posterous_download_image" src="https://blogger.googleusercontent.com/tracker/895936018437336024-5983702829820608294?l=blog.sidmitra.com" height="1" alt="" width="1"></div></div>