+++
title = "LinkStash - 13 Mar '08"
date = "2008-03-15T05:48:00-03:00"
type = "post"
tags = ['linkstash']
+++

<div class="posthaven-post-body">  <ul>
<li>
<a href="http://divinecaroline.com/article/22242/45922-world-s-most-incredible-hotel-swimming" title="http://divinecaroline.com/article/22242/45922-world-s-most-incredible-hotel-swimming">World's Most Incredible Hotel Swimming Pool</a> - SIGH!  </li> </ul><div align="center">   <p>        <div class="posthaven-gallery" id="posthaven_gallery[445302]">
                  <p class="posthaven-file posthaven-file-image posthaven-file-state-processed">
          <img class="posthaven-gallery-image" src="https://phaven-prod.s3.amazonaws.com/files/image_part/asset/783143/pzcNVMhM7niiVykxxr-DsSlYmHE/media_httpwwwsevennat_ljhGa.jpg" />
        </p>

        </div>
         <div class="posthaven-gallery" id="posthaven_gallery[445303]">
                  <p class="posthaven-file posthaven-file-image posthaven-file-state-processed">
          <img class="posthaven-gallery-image" src="https://phaven-prod.s3.amazonaws.com/files/image_part/asset/783144/QnWyTaSPe3-bW3W2HIvL4HNfquU/media_httpwwwsevennat_oGngk.jpg" />
        </p>

        </div>
 </p> </div>  <p> </p>  <ul>
<li>
<a href="http://break.com/index/awareness-test.html" title="http://break.com/index/awareness-test.html">Can you pass the test??</a> - Simply count the number of passes the team in white makes :-D Best of Luck</li> </ul><p> </p>  <ul>
<li>
<a href="http://www.neatorama.com/2006/08/29/the-wonderful-world-of-early-photography/" title="http://www.neatorama.com/2006/08/29/the-wonderful-world-of-early-photography/">20 incredible 'Firsts' in the world of photography</a> - Have you ever seen the world's oldest coloured photograph?</li> </ul><p> </p>  <ul>
<li> <a href="http://flickrvision.com/">FlickrVision</a> - Geolocated photos in realtime!! Something similar to TwitterVision</li> </ul><p> </p>  <ul>
<li>
<a href="http://windowseat.ca/viscosity/">Viscosity</a> - Modern art generator. Nice if you a have couple of minutes to kill. </li> </ul><p> </p>  <ul>
<li>
<a href="http://www.ukimagehost.com/uploads/385929e955.jpg">How mario sees the world</a> -- eerie!! </li> </ul><p> </p>  <ul>
<li>
<a href="http://www.immersivemedia.com/">Immersive Media</a> - Sucks some bandwidth but definitely worth a watch. <strong>Note</strong>: Click and drag the mouse on the video screen to pan.</li> </ul><p> </p>  <p> </p>  <blockquote>   <p><em>Catch further issues of the fumbleLog by subscribing to the  </em><a href="http://feeds.feedburner.com/fumblelog"><strong><em>RSS Feed</em></strong></a>.</p>
</blockquote>  <div class="blogger-post-footer"><img class="posterous_download_image" src="https://blogger.googleusercontent.com/tracker/895936018437336024-258253145379829570?l=blog.sidmitra.com" height="1" alt="" width="1"></div></div>