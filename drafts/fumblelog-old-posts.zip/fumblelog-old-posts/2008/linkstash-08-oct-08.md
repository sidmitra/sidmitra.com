+++
title = "LinkStash - 08 Oct' 08"
date = "2008-10-08T02:19:00-04:00"
type = "post"
tags = ['linkstash']
+++

<div class="posthaven-post-body">  <p> </p>  <ul>
<li>
<a href="http://www.techcult.com/the-150-best-online-flash-games/" title="http://www.techcult.com/the-150-best-online-flash-games/">The 150 best online flash games</a> – it’s on the top of my Todo list. </li>    <li>
<a href="http://www.jakevoytko.com/blog/2008/10/06/lisp-is-changing-my-c/" title="http://www.jakevoytko.com/blog/2008/10/06/lisp-is-changing-my-c/">Lisp is changing my C++</a> </li>    <li>
<a href="http://appnr.com/" title="http://appnr.com/">Appnr</a> – Install Ubuntu applications </li>    <li>
<a href="http://torvalds-family.blogspot.com/" title="http://torvalds-family.blogspot.com/">Linus Torvald</a> - coming to a blog near you </li> </ul><p> </p>  <blockquote>   <p align="left">“Saying that Java is nice because it works on all OSes is like saying that anal sex is nice because it works on all genders.”  -  Alanna</p> </blockquote>  <p> </p>  <div align="center">        <div class="posthaven-gallery" id="posthaven_gallery[445293]">
                  <p class="posthaven-file posthaven-file-image posthaven-file-state-processed">
          <img class="posthaven-gallery-image" src="https://phaven-prod.s3.amazonaws.com/files/image_part/asset/783138/BIkiagZWm8pj3goP8RTjFDQ5yDI/media_httpfarm4static_GsvbC.jpg" />
        </p>

        </div>
     <br><a href="http://www.flickr.com/photos/now-in-iceland/2917617879/">Northern lights at the summer house</a> by <a href="http://www.flickr.com/photos/now-in-iceland/">Now in Iceland</a> </div>  <p> </p>  <blockquote>   <p align="center">“Any fool can use a computer.  Many do.”   -  Ted Nelson</p> </blockquote>  <p> </p>  <ul>
<li>
<a href="http://maketecheasier.com/8-ways-to-maintain-a-clean-lean-ubuntu-machine/2008/10/07/" title="http://maketecheasier.com/8-ways-to-maintain-a-clean-lean-ubuntu-machine/2008/10/07/">8 ways to maintain a clean lean Ubuntu machine</a> – Some points,       <ol></ol>
<ol></ol>
<ol>
<li>Analyze your disk usage </li>            <li>Clear duplicate files and broken symlinks </li>            <li>Clean up your package installation and more…. </li>         </ol>
<p> </p>   </li>    <li>
<a href="http://divisibleby0.com/dating/" title="http://divisibleby0.com/dating/">8 Phases of Dating</a> – Illustration by Matthew Inman </li> </ul><p></p>  <p> </p>  <p><strong>Recommended App</strong></p>  <ul>
<li>
<strong><a href="http://www.getmiro.com/">Miro</a></strong> – Is an internet media application or a podcast receiver like Juice. Nomally i wouldn’t recommend any app that uses as much memory as this one does, but I’m making an exception here. Juice had given me trouble in the past and refused to recognise previously downloaded files and somehow stopped downloading new media from subscribed feeds even when new episodes were available. So I switched to Miro a month back. Its easy to find content to listen to and watch through it now. It recommends new feeds and you can search directories for topics you like. It also keeps track of what episodes you’ve already seen. The killer feature being that if you start playing any video/audio and quit, Miro can automatically remember  the point where you last stopped and continue playing from there. One thing that does bug me is if you play a file and navigate to some other feed, the files stops playing. This starts getting irritating if you’re listening to some MP3 and want to browse some other channel offerings at the same time. But otherwise its a pretty good app for people just starting out on podcasts. </li> </ul><p> </p>  <ul>
<li>
<a href="http://www.youtube.com/v/MeSSwKffj9o">Religion</a> - George Carlin </li> </ul><p></p>  <div align="center"><object height="339" width="300"><param name="movie" value="http://www.youtube.com/v/MeSSwKffj9o&amp;hl=en&amp;fs=1&amp;color1=0x3a3a3a&amp;color2=0x999999&amp;border=1">
<param name="allowFullScreen" value="true">
<embed src="http://www.youtube.com/v/MeSSwKffj9o&amp;hl=en&amp;fs=1&amp;color1=0x3a3a3a&amp;color2=0x999999&amp;border=1" allowfullscreen="true" type="application/x-shockwave-flash" height="349" width="425"></embed></object>

</div>  <div align="center"> </div>  <p> </p>  <p> </p>  <blockquote>   <p>Subscribe to my <a href="http://feeds.feedburner.com/fumblelog"><strong>RSS</strong></a> feed… or subscribe to my <a href="http://friendfeed.com/sidmitra?format=atom">FriendFeed</a> for all the links and info I post over the web.</p>
</blockquote>  <div class="blogger-post-footer"><img class="posterous_download_image" src="https://blogger.googleusercontent.com/tracker/895936018437336024-4651541208826242482?l=blog.sidmitra.com" height="1" alt="" width="1"></div></div>