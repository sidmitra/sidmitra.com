+++
title = "Home by Hype"
date = "2008-06-30T21:08:00-04:00"
type = "post"
tags = ['music']
+++

<div class="posthaven-post-body">  <p>        <div class="posthaven-gallery" id="posthaven_gallery[445296]">
                  <p class="posthaven-file posthaven-file-image posthaven-file-state-processed">
          <img class="posthaven-gallery-image" src="https://phaven-prod.s3.amazonaws.com/files/image_part/asset/783140/dlm4oaBPY9s-Ar-ciyAM3_WCm_0/media_httpwwwdivshare_pidBF.jpg" />
        </p>

        </div>
</p> <object height="28" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="335"><param name="movie" value="http://www.divshare.com/flash/playlist?myId=4844394-a15">
<embed name="divplaylist" src="http://www.divshare.com/flash/playlist?myId=4844394-a15" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" height="28" width="335"></embed></object>  <p> </p>  <p>From the album <em><strong>Lies and Speeches</strong></em>, the song has a Cranberries like quality and dark cloudish beats. It’s a steal considering it’s free. You can download this whole album at Jamendo, by following the link below.</p>  <p><a href="http://www.jamendo.com/en/album/1289" title="on jamendo.com">Listen to more of Hype..</a></p>  <div class="blogger-post-footer"><img class="posterous_download_image" src="https://blogger.googleusercontent.com/tracker/895936018437336024-3779227031419004390?l=blog.sidmitra.com" height="1" alt="" width="1"></div></div>