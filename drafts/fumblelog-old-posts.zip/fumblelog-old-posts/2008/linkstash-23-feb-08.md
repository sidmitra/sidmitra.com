+++
title = "LinkStash - 23 Feb '08"
date = "2008-02-23T04:33:00-03:00"
type = "post"
tags = ['linkstash']
+++

<div class="posthaven-post-body">  <p><strong>DevStash</strong></p>  <ul>
<li>
<a href="http://portal.acm.org/toc.cfm?id=SERIES11430&amp;type=series&amp;coll=ACM&amp;dl=ACM"><strong>ACM Classic Books Series</strong></a> - Some of the favourite computer science books as polled by ACM members. </li> </ul><p> </p>  <p><strong>Pics</strong></p>  <p>I'm really fascinated by photography these days. </p>  <ul>
<li>     <div align="center">        <div class="posthaven-gallery" id="posthaven_gallery[445307]">
                  <p class="posthaven-file posthaven-file-image posthaven-file-state-processed">
          <img class="posthaven-gallery-image" src="https://phaven-prod.s3.amazonaws.com/files/image_part/asset/783147/d_SH-oNhvy4mxkU1pQzolJX1ft0/media_httpuploadwikim_okxhs.jpg" />
        </p>

        </div>
         <br>Broadway Tower by <a href="http://en.wikipedia.org/wiki/User:Newton2">Newton2</a>
</div>   </li> </ul><p> </p>  <ul>
<li>
<a href="http://funtasticus.com/20080212/sexy-lips/#more-1980" title="http://funtasticus.com/20080212/sexy-lips/#more-1980"><strong>Sexy Lips</strong></a> - An amazing colection of photographs on you guessed it, Lips. </li> </ul><p> </p>  <p><strong>Vids</strong></p>  <p>Having seen loads of cool videos this past week. Here's some you might enjoy.</p>  <ul>
<li>
<a href="http://www.kontraband.com/show/show.asp?ID=10314"><strong>Paul Hunt</strong></a> - The most manly Gymnast ever, courtesy kontraband. </li> </ul><p> </p>  <ul>
<li>
<a href="http://www.youtube.com/watch?v=XngQJzAmVm8&amp;NR=1"><strong>A Water Balloon Not Exploding</strong></a> - Everything looks good at slo-mo </li> </ul><p> </p>  <div align="center"><embed src="http://www.youtube.com/v/XngQJzAmVm8" type="application/x-shockwave-flash" wmode="transparent" height="237" style="height: 237px;" width="301"></embed></div>  <div align="center"> </div>  <p><strong>Flash</strong></p>  <ul>
<li>
<a href="http://fc01.deviantart.com/fs13/f/2007/077/2/e/Animator_vs__Animation_by_alanbecker.swf" title="http://fc01.deviantart.com/fs13/f/2007/077/2/e/Animator_vs__Animation_by_alanbecker.swf"><strong>Animator vs Animation</strong></a> - By Alan Becker. Wow!! so many cool ideas in here. Must watch! </li> </ul><p> </p>  <p><strong>Chaos</strong></p>  <ul>
<li>
<a href="http://metaatem.net/selcolor.php" title="http://metaatem.net/selcolor.php"><strong>Fun with Highlights</strong></a> - Open with Firefox or Safari. Too bad didn't work with Opera :-( </li> </ul><p> </p>  <ul>
<li>
<a href="http://scribalterror.blogs.com/scribal_terror/2008/01/the-pee-shivers.html"><strong>The Pee Shivers</strong></a> - Ever wondered why it happens?? </li> </ul><p> </p>  <ul>
<li>
<a href="http://socwall.com/" title="http://socwall.com/"><strong>SocWall</strong></a> - Social wallpapering...a cool concept. I get all my wallpapers from here now :-D </li> </ul><p> </p>  <blockquote>   <p>Catch further issues by subscribing to my <a href="http://feeds.feedburner.com/fumblelog"><strong>RSS Feed</strong></a>.</p>
</blockquote>  <div class="blogger-post-footer"><img class="posterous_download_image" src="https://blogger.googleusercontent.com/tracker/895936018437336024-8995456890605530656?l=blog.sidmitra.com" height="1" alt="" width="1"></div></div>