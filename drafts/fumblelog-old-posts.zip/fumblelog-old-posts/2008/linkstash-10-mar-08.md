+++
title = "LinkStash - 10 Mar '08"
date = "2008-03-09T19:52:00-03:00"
type = "post"
tags = ['linkstash']
+++

<div class="posthaven-post-body">  <p> </p>  <blockquote class="posterous_medium_quote">   <p>“”Life is pretty simple: You do some stuff. Most fails. Some works.      <br>You do more of what works. If it works big, others quickly copy it.       <br>Then you do something else. The trick is the doing something else.”       <br>Leonardo da Vinci</p> </blockquote>  <ul>
<li>
<a href="http://thefeelgood.com/">The feel good initiative</a> - " A source of inspiration music and art." Amazing songs... just perfect for those all-nighters spent hacking away. </li> </ul><p> </p>  <ul>
<li>
<a href="http://artofmanliness.com/2008/02/19/make-yourself-stick-with-these-first-impression-tips/" title="http://lifehacker.com/364461/how-to-leave-a-great-first-impression">Make Yourself Stick with these First Impression Tips</a> - Mostly common sense... but we still tend to forget sometimes :-D</li> </ul><p> </p>  <ul>
<li>
<a href="http://my.opera.com/MacDev_ed/blog/2008/02/05/how-to-do-photoshop-like-effects-in-svg">How to do photoshop-like effects in SVG</a> - SVG  " is an XML specification and file format for describing two-dimensional vector graphics, both static and animated. " </li> </ul><p> </p>  <ul>
<li>
<a href="http://mashable.com/2008/03/01/india-outsourcing/" title="http://mashable.com/2008/03/01/india-outsourcing/">Indian IT: Outsourcing To Decline?</a> - Is it time to de-bangalore? </li> </ul><p> </p>  <ul>
<li>
<a href="http://ubuntulinuxhelp.com/top-100-of-the-best-useful-opensource-applications/" title="http://ubuntulinuxhelp.com/top-100-of-the-best-useful-opensource-applications/">Top 100 of the Best (Useful) OpenSource Applications</a> </li> </ul><p> </p>  <div align="center">   <p>        <div class="posthaven-gallery" id="posthaven_gallery[445304]">
                  <p class="posthaven-file posthaven-file-image posthaven-file-state-processed">
          <img class="posthaven-gallery-image" src="https://phaven-prod.s3.amazonaws.com/files/image_part/asset/783145/D4_1FoD--xJU30nvud4A5VBPKw0/media_httpfarm4static_Jpqpp.jpg" />
        </p>

        </div>
 </p>    <p>A Magic Evening - by <a href="http://www.flickr.com/photos/stuckincustoms/" title="http://www.flickr.com/photos/stuckincustoms/">Stuck in Customs</a></p> </div>  <p> </p>  <p><a href="http://speckyboy.com/2008/03/08/63-essential-wordpress-hacks-tutorials-help-files-and-cheats/" title="http://speckyboy.com/2008/03/08/63-essential-wordpress-hacks-tutorials-help-files-and-cheats/">63 Eessential Wordpress Hacks</a> - feels like cheating after having shifter to blogger again. Would have stuck to WP if had my own hosting to customize..SIGH</p>  <p> </p>  <p><a href="http://sysadminry.wordpress.com/2008/03/09/sexy-clones-of-classic-unix-tools/" title="http://sysadminry.wordpress.com/2008/03/09/sexy-clones-of-classic-unix-tools/">Sexy Clones of Classic Unix Tools</a> - I never heard of some of them.. might be worth a look.</p>  <p> </p>  <blockquote>   <p>Catch further issues by subscribing to my <a href="http://feeds.feedburner.com/fumblelog"><strong>RSS Feed</strong></a>.</p>
</blockquote>  <div class="blogger-post-footer"><img class="posterous_download_image" src="https://blogger.googleusercontent.com/tracker/895936018437336024-1229121502824156644?l=blog.sidmitra.com" height="1" alt="" width="1"></div></div>