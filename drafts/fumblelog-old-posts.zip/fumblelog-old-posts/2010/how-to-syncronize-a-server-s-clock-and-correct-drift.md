+++
title = "How to syncronize a server's clock and correct drift"
date = "2010-04-01T14:40:00-03:00"
type = "post"
tags = ['sysadmin']
+++

<div class="posthaven-post-body"><div>Servers with large uptime, might gather quite a few seconds of drift in their clocks. To synchronize the server's time with an external source, simple run the following:</div>
<p></p>
<p></p><pre><code>sudo apt-get install ntp ntpdate
sudo ntpdate pool.ntp.org ntp.ubuntu.com
</code></pre>
<p></p>
<div>If you get an error while about the port being in use, then you might try killing the previous running ntp process and trying again.</div>
<div>It would also be a good idea to add the second line to your cron tab as a daily run.</div>
<p></p>
<div>
<strong>Reference:</strong><br><a href="https://help.ubuntu.com/8.04/serverguide/C/NTP.html">https://help.ubuntu.com/8.04/serverguide/C/NTP.html</a><br><a href="http://ubuntuforums.org/archive/index.php/t-198961.html">http://ubuntuforums.org/archive/index.php/t-198961.html</a><p></p>
</div></div>