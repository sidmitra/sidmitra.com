+++
title = "How to rename a tag already pushed to a remote git repo"
date = "2010-10-14T00:11:00-03:00"
type = "post"
tags = ['git']
+++

<div class="posthaven-post-body"><p>Here’s a quick git tip that i end up searching each time i need to do it. So i’m posting this here.   There’s plenty of times i’ve added a tag, pushed to remote and realised that i’d named it wrong. Eg. 1.59 instead of 1.49 .  To change it back you would need to add a new tag and push it,</p>

<div class="CodeRay">
  <div class="code"><pre>$&gt; git tag new_tag old_tag
$&gt; git push --tags

Total 0 (delta 0), reused 0 (delta 0)
To git@github.com:some.git
     * [new tag]         new_tag -&gt; new_tag</pre></div>
</div>


<p>Then delete the old tag from remote and local</p>

<div class="CodeRay">
  <div class="code"><pre>$&gt; git push origin :refs/tags/old_tag
$&gt; git tag -d old_tag</pre></div>
</div>


<p>But remember this can screw around with other people local repositories if they’ve already pulled before you make the change. So be careful!</p></div>