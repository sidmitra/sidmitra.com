+++
title = "Getting up and running with Django nonrel"
date = "2010-05-28T23:40:00-04:00"
type = "post"
tags = ['appengine', 'django', 'nonrel']
+++

<div class="posthaven-post-body"><p><strong>This POST might be slightly out of date from time to time. See <a href="http://github.com/sidmitra/django_nonrel_testapp"><strong>http://github.com/sidmitra/django_nonrel_testapp</strong></a>.</strong></p>

<p>The Django nonrel project is an attempt to make django work with non relational backends. They’ve also made a Google AppEngine backend for the same. Thus, now you can easily run native django apps on GAE.</p>

<p>Some caveats first, there are some features from Django that are missing(like joins! which is coming) or some that aren’t perfect yet but it’s a good start to port over any existing simple apps that you already have on Django. Something you should keep in mind is that there’s no way to mix the native django models with those that appengine provides. Some of the steps i took to get it running are specified below. In case you are too lazy :–), I have a Github repository for the same at <a href="http://github.com/sidmitra/django_nonrel_testapp">http://github.com/sidmitra/django_nonrel_testapp</a>.**</p>

<h1>Downloading stuff</h1>

<p>Getting a simple test app running with nonrel is simple. But you would need to install <a href="http://mercurial.selenic.com">Mercurial</a> first. Once you have that up and running, they project already provides a sample project to support the dev server. So you can start by cloning all required repositories first.</p>

<div class="CodeRay">
  <div class="code"><pre>hg clone http://bitbucket.org/wkornewald/django-nonrel
hg clone http://bitbucket.org/wkornewald/django-testapp/
hg clone http://bitbucket.org/wkornewald/djangoappengine/
hg clone http://bitbucket.org/wkornewald/djangotoolbox/
hg clone http://bitbucket.org/wkornewald/django-dbindexer/src</pre></div>
</div>


<h1>Setting it up</h1>

<p>django-nonrel is the main project containing a modified django, and we need djangoappengine, djangotoolbox as further dependencies. django-testapp is the sample app created with custom configuration to make this quicker.</p>

<div class="CodeRay">
  <div class="code"><pre>cd django-testapp
cp -R ../django-nonrel/django django
cp -R ../djangoappengine djangoappengine
cp -R ../djangotoolbox/djangotoolbox djangotoolbox
cp -R ../django-dbindexer/dbindexer dbindexer
python manage.py runserver</pre></div>
</div>


<p>And that’s it. Essentially we’ve copied all the dependencies into the project folder. So your directory structure should look something like this.</p>

<div class="CodeRay">
  <div class="code"><pre>* django-testapp
     * django
     * djangotoolbox
     * djangoappengine
     * dbindexer 
     * ...</pre></div>
</div>


<p>You can also use links on linux instead of copying the directories. On windows install <a href="http://schinagl.priv.at/nt/hardlinkshellext/hardlinkshellext.html">Link shell extension</a>. You can drop junctions into the common-apps folder.</p>

<p>Source:</p>

<p><a href="http://www.allbuttonspressed.com/blog/django/2010/01/Native-Django-on-App-Engine">http://www.allbuttonspressed.com/blog/django/2010/01/Native-Django-on-App-Engine</a>
<a href="http://www.allbuttonspressed.com/projects/djangoappengine#docu">http://www.allbuttonspressed.com/projects/djangoappengine#docu</a></p></div>