+++
title = "How to add request.user to HTTP 500 error reports on Django?"
date = "2010-10-26T02:32:00-03:00"
type = "post"
tags = ['django']
+++

<div class="posthaven-post-body"><p>  Continuing on from the last post, django provides an excellent hook in middlewares to process exception. You can add a new middleware and override the process_handler exception to add any kind of info to the request object. This info then shows up on the errors displayed on the screen(in debug mode) or sent as email. Profit!</p>

<div class="CodeRay">
  <div class="code"><pre><span class="keyword">class</span> <span class="class">ExceptionUserInfoMiddleware</span>(<span class="predefined">object</span>):
    <span class="comment"><span class="delimiter">"""</span><span class="content">
</span><span class="content">    Adds user details to request.META, so that they show up in</span><span class="content">
</span><span class="content">    the error emails.</span><span class="content">
</span><span class="content">
</span><span class="content">    Add to settings.MIDDLEWARE_CLASSES and keep it outermost</span><span class="content">
</span><span class="content">    (i.e. on top if possible). This allows it to catch exceptions </span><span class="content">
</span><span class="content">    in other middlewares as well.</span><span class="content">
</span><span class="content">    </span><span class="delimiter">"""</span></span>

    <span class="keyword">def</span> <span class="function">process_exception</span>(<span class="predefined-constant">self</span>, request, exception):
        <span class="comment"><span class="delimiter">"""</span><span class="content">
</span><span class="content">        Process the exception.</span><span class="content">
</span><span class="content">
</span><span class="content">        :Parameters:</span><span class="content">
</span><span class="content">           - `request`: request that caused the exception</span><span class="content">
</span><span class="content">           - `exception`: actual exception being raised</span><span class="content">
</span><span class="content">        </span><span class="delimiter">"""</span></span>

        <span class="keyword">try</span>:
            <span class="keyword">if</span> request.user.is_authenticated():
                request.META[<span class="string"><span class="delimiter">'</span><span class="content">USERNAME</span><span class="delimiter">'</span></span>] = <span class="predefined">str</span>(request.user.username)
                request.META[<span class="string"><span class="delimiter">'</span><span class="content">USER_EMAIL</span><span class="delimiter">'</span></span>] = <span class="predefined">str</span>(request.user.email)
        <span class="keyword">except</span>:
            <span class="keyword">pass</span></pre></div>
</div>


<p>You can also find the latest version of this snippet at <a href="http://gist.github.com/646372">http://gist.github.com/646372</a></p></div>