+++
title = "Upgrade to Apache 2.2.16 on Ubuntu Lucid"
date = "2010-10-13T01:06:00-03:00"
type = "post"
tags = ['ubuntu sysadmin']
+++

<div class="posthaven-post-body"><p>Ubuntu Lucid only contain Apache 2.2.14 in their repos. In case you intend to install a newer version you don’t have to worry about downloading, and installing all dependencies. Luckily the new Maverick repos contain the newer version. Thus, all you need is to add them to your sources.list</p>

<div class="CodeRay">
  <div class="code"><pre>#Add the following line to /etc/apt/sources.list
#deb http://cz.archive.ubuntu.com/ubuntu maverick main
#and run the commands below.

sudo apt-get update
sudo apt-get install apache2</pre></div>
</div>


<p>Also remember to remove the new repo, otherwise it might try to update   everything and you certainly don’t want that. I recently upgraded to Maverick, and loving the new font!</p></div>