+++
title = "Retrieve user names from session ID in Django errors"
date = "2010-10-24T01:57:00-03:00"
type = "post"
tags = ['django']
+++

<div class="posthaven-post-body"><p>Django error emails on 500 errors are pretty useless if you’re the acting<br>
customer support for the day. There’s absolutely not much besides a<br>
session ID, to identify which user actually got that exception. Obviously<br>
for a startup, that’s essential to reacho out to little customers we do<br>
have, if for nothing else than to apologize. Anyways here’s a simple<br>
little snippet that can help you figure out a user from a session id.<br>
Note, that the user might not be logged in, in that case there’s not much<br>
you can do.</p>

<div class="CodeRay">
  <div class="code"><pre><span class="keyword">def</span> <span class="function">get_user_from_sessionid</span>(sessionid):
       <span class="comment"><span class="delimiter">"""</span><span class="content">
</span><span class="content">       ``sessionid`` - is the identifier for the users session. </span><span class="content">
</span><span class="content">       You can also find it in the Http500 error messages on screen</span><span class="content">
</span><span class="content">       or via email.</span><span class="content">
</span><span class="content">
</span><span class="content">       &gt;&gt;&gt; get_user_from_sessionid('fd3479022d77794897e5b23f4d461bbf')</span><span class="content">
</span><span class="content">       </span><span class="delimiter">"""</span></span>
       <span class="keyword">from</span> <span class="include">django.contrib.sessions.models</span> <span class="keyword">import</span> <span class="include">Session</span>
       <span class="keyword">from</span> <span class="include">django.contrib.auth.models</span> <span class="keyword">import</span> <span class="include">User</span>


       session = Session.objects.get(session_key=sessionid)
       uid = session.get_decoded().get(<span class="string"><span class="delimiter">'</span><span class="content">_auth_user_id</span><span class="delimiter">'</span></span>)
       user = User.objects.get(pk=uid)

       <span class="keyword">return</span> user.id, user.username, user.email</pre></div>
</div>


<h2>Links</h2>

<ul>
<li>
<a href="http://code.google.com/p/django-command-extensions/">http://code.google.com/p/django-command-extensions/</a> – There is already a command in django-extensions, called ‘print_user_for_session’ that does<br>
the same.</li>
<li>
<a href="http://djangosnippets.org/snippets/1276/">http://djangosnippets.org/snippets/1276/</a> – for a backend agnostic method.</li>
<li>
<a href="http://scottbarnham.com/blog/2008/12/04/get-user-from-session-key-in-django/">http://scottbarnham.com/blog/2008/12/04/get-user-from-session-key-in-django/</a> – is practically the same snippet as above.</li>
</ul><p>There’s also a way to add the username to the error emails themselves, by overriding a process_exception on a middleware.
You can read about it <a href="/how-to-add-requestuser-to-500-error-reports-o"><strong>here</strong></a></p>

<p>.</p></div>