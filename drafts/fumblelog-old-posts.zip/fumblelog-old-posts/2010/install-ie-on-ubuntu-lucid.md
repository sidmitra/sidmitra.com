+++
title = "Install IE on Ubuntu Lucid"
date = "2010-09-26T01:53:00-04:00"
type = "post"
tags = []
+++

<div class="posthaven-post-body"><p>I recently switched to Ubuntu Lucid from Windows XP. Switching to a new OS
is probably harder than the decision to change one’s religion. Being a web
developer, IE is unfortunately a staple diet for most of us. Unfortunately
i couldn’t get IEs4Linux to run on Lucid. After trying to figure out loads
of install issues, and then almost settling on virtualbox, i just found
out about winetricks.</p>

<div class="CodeRay">
  <div class="code"><pre>$&gt;wget http://www.kegel.com/wine/winetricks
$&gt;sh winetricks</pre></div>
</div>


<p>and it should pop up a box with tools you can install and simply select IE8 or other goodies to choose from.</p></div>