+++
title = "Expanding your arsenal with virtualenv and virtualenvwrapper "
date = "2011-01-23T13:35:00-03:00"
type = "post"
tags = ['django', 'python']
+++

<div class="posthaven-post-body"><p>If you’re a freelancer, then you’re probably working on multiple projects at the same time. If by any chance the projects use different versions of django, then you’re pretty much in version hell, writing bash scripts to change paths and all the other sins. This is where virtualenv will save your rear end.</p>

<p><strong>virtualenv</strong> is a python module to help you isolate virtual python enviroments. Each environment will have its own python executable, it’s own site-packages effectively allowing you to install completely diferent dependencies for each project.</p>

<h2>Installation</h2>

<p>First we’ll simply install virtualenv. We’ll also use Doug Hellman’s awesome virtualenvwrapper (<a href="http://www.doughellmann.com/projects/virtualenvwrapper/)">http://www.doughellmann.com/projects/virtualenvwrapper/)</a>. It will allow us to organize all virtual environments at once place.</p>

<p>I prefer pip to all the dirty work for me. So simply run,</p>

<div class="CodeRay">
  <div class="code"><pre>easy_install pip
pip install virtualenv
pip install virtualenvwrapper</pre></div>
</div>


<p>This should install both packages to the global python site-packages.  One thing to note during installation is the path to virtualenvwrapper.sh. It will be printed during installation.  Typically it’s found at /usr/local/bin/virtualenvwrapper.sh . We’ll need this later.</p>

<p>There’re some extra steps to setup virtualenvwrapper. If you’re on *nix then add the following lines at the top of ~/.bashrc . Here we’re just specifying that we want to save all our environments in a particular directory.</p>

<div class="CodeRay">
  <div class="code"><pre># virtualenvwrapper
export WORKON_HOME=~/.virtualenvs
source /usr/local/bin/virtualenvwrapper.sh
export PIP_VIRTUALENV_BASE=$WORKON_HOME
export PIP_RESPECT_VIRTUALENV=true</pre></div>
</div>


<p>Now let’s create that directory, and initialize virtualenvwrapper</p>

<div class="CodeRay">
  <div class="code"><pre>mkdir ~/.virtualenvs
source ~/.bashrc</pre></div>
</div>


<h2>Usage</h2>

<div class="CodeRay">
  <div class="code"><pre>mkvirtualenv --no-site-packages myenv</pre></div>
</div>


<p>This will create an environment and not import the global packages. This is important. This means it only uses libraries/versions in the local env.
I prefer to do this on all production environments to make sure upgrading a global package doesn’t affect the web app running on the current venv.
The only down side is that you’ve to install all the modules again in each new environment you create. You can choose to skip the argument —no-site-packages, and it will use all the modules in your global python path.</p>

<p>To enable a particular environment, virtualenvwrapper gives us some shortcut scripts. This will change the prompt to show the name of the current environment, eg. (myenv)$&gt;</p>

<div class="CodeRay">
  <div class="code"><pre>workon myenv</pre></div>
</div>


<h2>Tips</h2>

<p>You have a brand new virtual environment to play with. While it’s active you can pretty much install any module an it will be installed only for this environment. Your global packages will be safe as ever. Also it’s a good idea to keep all your project dependencies in a requirements.txt file.</p>

<div class="CodeRay">
  <div class="code"><pre>cd ~/go/to/project/dir
 pip install -r requirements.txt</pre></div>
</div>


<p>A sample requirements file could look like the following.</p>

<div class="CodeRay">
  <div class="code"><pre>django==1.2.4
South==0.7.2</pre></div>
</div>


<p>You can try $&gt;pip freeze &gt; requirements.txt to port an existing virtualenvironment to a requirements file. Now you can add a step to your deployment script to install all required dependencies each time. Fabric is also an awesome tool that every Django programmer should know and use.</p>

<p>There are other awesome things that will save you time. If you goto your WORKON_HOME dir, you will notice files like <em>postactivate</em>, <em>postdeactivate</em>. These are global shell scripts that you can add commands to. They will be exectued on each activate, deactivate etc. Infact each environment directory inside can have their own hooks like these. Enough spoon feeding, browse the docs to find out more.</p>

<p>THATS IT.</p>

<p>But wait!! it’s not that easy. If you’re running a django project like this, you’ll have a hell of a time installing modules like mysql-python, PIL etc. using pip inside a virtualenv. They need to be compiled, and due to changed paths the correct libraries aren’t found on a fresh system. I’ll explain some more common gotchas on my next post.</p>

<h2>Sources</h2>

<ul>
<li>  <a href="http://virtualenv.openplans.org/">http://virtualenv.openplans.org/</a>
</li>
<li>  <a href="http://www.doughellmann.com/projects/virtualenvwrapper/">http://www.doughellmann.com/projects/virtualenvwrapper/</a>
</li>
</ul></div>