+++
title = "Turbo charge apt-get with apt-fast"
date = "2011-04-04T23:55:00-03:00"
type = "post"
tags = []
+++

<div class="posthaven-post-body"><p>You can easily make apt-get use a download accelerator for faster upgrades. Using apt-fast, which is simply a script that uses Axel, a command line application which accelerates HTTP/FTP downloads by using multiple sources for one file.</p>

<h1>Installation</h1>

<div class="CodeRay">
  <div class="code"><pre>sudo apt-get install axel
cd ~/Desktop
wget http://www.mattparnell.com/linux/apt-fast/apt-fast.sh
mv apt-fast.sh /usr/bin/apt-fast
sudo chmod +x /usr/bin/apt-fast</pre></div>
</div>


<h1>Usage</h1>

<p>Now you can use apt-fast instead of apt-get and it will use our download accelerator to speed things along.</p>

<div class="CodeRay">
  <div class="code"><pre>sudo apt-fast install htop
sudo apt-fast update</pre></div>
</div>


<h2>Source</h2>

<p><a href="http://www.mattparnell.com/projects/apt-fast-and-axel-roughly-26x-faster-apt-get-installations-and-upgrades.html">http://www.mattparnell.com/projects/apt-fast-and-axel-roughly-26x-faster-apt-...</a></p></div>