+++
title = "Poor man's database backup using Dropbox"
date = "2011-04-06T00:20:00-03:00"
type = "post"
tags = []
+++

<div class="posthaven-post-body"><p>If you’re using a lot of cheap VPS like me, then you you need a way to ship database backups to a third party site. If you’re on EC2, then you’re probably shipping it to Amazon S3. Other providers have their own automated techniques for backup. I have a lot of smaller sites that run on cheap VPS, with no backup solutions. I tend to use dropbox to sync them out to external storage. It’s not the best way, but it’s definitely cheap(read free), and quick to setup. More importanntly you can automatically have them sync to your local or any machines that you want!!!</p>

<p>Dropbox basically designates a folder on your computer as a sync folder. Any changes to that folder are synced to the cloud automatically if the dropbox service is running on local.</p>

<h1>Installation</h1>

<p>To install dropbox on your server, you simply run the following,</p>

<div class="CodeRay">
  <div class="code"><pre>cd ~     wget -O dropbox.tar.gz "http://www.dropbox.com/download/?plat=lnx.x86"

#For x64, use below:
#wget -O dropbox.tar.gz "http://www.dropbox.com/download/?plat=lnx.x86_64"

tar -tzf dropbox.tar.gz     
tar -xvzf dropbox.tar.gz</pre></div>
</div>


<h1>Configure</h1>

<p>To link your server with an account run the following</p>

<div class="CodeRay">
  <div class="code"><pre>~/.dropbox-dist/dropboxd</pre></div>
</div>


<p>This will print out a link. You can visit that link and and it will ask you to create an account. This will automatically hookup that dropbox account to your local/server machine that you ran this on.</p>

<div class="CodeRay">
  <div class="code"><pre>This client is not linked to any account...     
Please visit https://www.dropbox.com/cli_link?host_id=7aaaaa8f285f2da0x67334d02c1 to link this machine.</pre></div>
</div>


<p>Once you’ve signed up you can actually see dropboxd command line acknowledge the account creation. You can close the daemon by running ctrl+c. To run it again in the background so it syncs automatically always, run</p>

<div class="CodeRay">
  <div class="code"><pre>~/.dropbox-dist/dropboxd &amp;</pre></div>
</div>


<h1>Usage</h1>

<p>You have to run the dropboxd daemon to sync automatically, so make sure its running by running htop or top. Once you’ve done that, you can also make sure you have a directory called Dropbox on your home folder.</p>

<div class="CodeRay">
  <div class="code"><pre>cd ~/Dropbox</pre></div>
</div>


<p>To backup anything simply move it to this folder. For eg. i periodically run a cronjob that dumps the live sql database to this folder. See below for an example. You can dump hourly backups of your database this way and they’ll be uploaded to dropbox. You can also set your local machine to use the same account and they’ll be downloaded on your machine as well. Instant gratification!!</p>

<div class="CodeRay">
  <div class="code"><pre>mysqldump --single-transaction -h -u -p &gt; ~/Dropbox/dump.sql</pre></div>
</div>


<p>More Dropbox tricks to come later.</p>

<h2>Source</h2>

<p><a href="http://wiki.dropbox.com/TipsAndTricks/TextBasedLinuxInstall">http://wiki.dropbox.com/TipsAndTricks/TextBasedLinuxInstall</a></p></div>