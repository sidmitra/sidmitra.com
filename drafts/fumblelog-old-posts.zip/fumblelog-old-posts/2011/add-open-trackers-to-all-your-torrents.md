+++
title = "Add Open Trackers to all your torrents"
date = "2011-05-11T03:23:00-04:00"
type = "post"
tags = ['torrents']
+++

<div class="posthaven-post-body"><p>Here're some open trackers that I add to every new torrent file I download. They're pretty useful, since most of the time they help me get the number of peers up for some of the rare ones.</p>
<p>Most modern torrent clients would let you add new trackers. You just need to add the following lines:</p>
<p> </p>
<blockquote class="posterous_medium_quote">
<p>udp://tracker.publicbt.com:80/announce</p>
<p> </p>
<p>udp://tracker.openbittorrent.com:80/announce</p>
<p>udp://tracker.openbittorrent.com:80</p>
<p> </p>
<p><a href="http://z6gw6skubmo2pj43.onion:8080/announce">http://z6gw6skubmo2pj43.onion:8080/announce</a></p>
<p><a href="https://kg6zclbtm7kwqide.tor2web.org/announce">https://kg6zclbtm7kwqide.tor2web.org/announce</a></p>
</blockquote>
<p> </p>
<p>See below for more info and a list of more trackers.</p>
<p> </p>
<p><span><strong>References</strong></span></p>
<ul>
<li><a href="http://publicbt.com/">http://publicbt.com/</a></li>
<li><a href="http://openbittorrent.com/">http://openbittorrent.com/</a></li>
<li><a href="https://z6gw6skubmo2pj43.tor2web.org/www/pages/home.html">https://z6gw6skubmo2pj43.tor2web.org/www/pages/home.html</a></li>
<li><a href="http://extratorrent.com/article/71/public+open+torrent+trackers.html">http://extratorrent.com/article/71/public+open+torrent+trackers.html</a></li>
</ul></div>